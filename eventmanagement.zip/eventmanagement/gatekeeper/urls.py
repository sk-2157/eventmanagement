from django.urls import path
from . import views

urlpatterns = [
    path('webcam/<str:event_name>', views.webcam, name='webcam'),
    path('gatekeeper_login/', views.gatekeeper_login, name='gatekeeper_login'),
    path('gatekeeper_dashboard', views.gatekeeper_dashboard, name='gatekeeper_dashboard'),
    path('gatekeeper_logout/', views.gatekeeper_logout, name='gatekeeper_logout'),
]
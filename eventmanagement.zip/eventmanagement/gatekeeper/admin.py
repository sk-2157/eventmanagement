from django.contrib import admin
from .models import Gatekeeper

# Register your models here.
class GatekeeperAdmin(admin.ModelAdmin):
    list_display = ('id','gatekeeper')
    list_display_links = ('id','gatekeeper')
    search_fields = ('gatekeeper',)
    list_per_page = 25  

admin.site.register(Gatekeeper, GatekeeperAdmin)
from django.shortcuts import render, redirect
from django.contrib import messages, auth
from django.contrib.auth.models import User
from .models import Gatekeeper
from events.models import Event
import cv2, os
import face_recognition
# Create your views here.


def load_known_faces(directory):
    known_faces = []
    known_names = []

    for filename in os.listdir(directory):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            name = os.path.splitext(filename)[0]
            image_path = os.path.join(directory, filename)
            face_image = face_recognition.load_image_file(image_path)
            face_encoding = face_recognition.face_encodings(face_image)[0]
            
            known_faces.append(face_encoding)
            known_names.append(name)

    return known_faces, known_names

def recognize_face(frame, known_faces, known_names):
    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)

    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        results = face_recognition.compare_faces(known_faces, face_encoding)

        if any(results):
            name = known_names[results.index(True)]
        else:
            name = "Unknown"

        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
        font = cv2.FONT_HERSHEY_DUPLEX
        cv2.putText(frame, name, (left + 6, bottom - 6), font, 0.5, (255, 255, 255), 1)

    return frame

def webcam(request,event_name):
    print(event_name)
    known_faces, known_names = load_known_faces(f"C:/Users/user/Documents/Python/Python/Django/eventmanagement/eventmanagement/media/{event_name}")

    # Open a video capture object (you may need to change the index or video file path)
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()

        if not ret:
            print("Failed to capture frame.")
            break

        frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)  # Resize for faster processing
        frame = recognize_face(frame, known_faces, known_names)

        cv2.imshow("Face Recognition", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    return redirect('gatekeeper_dashboard')

def gatekeeper_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username,password=password)
        if user is not None and Gatekeeper.objects.filter(gatekeeper=user, is_gatekeeper=True).exists():
            auth.login(request,user)
            messages.success(request, 'You are logged in successfully')
            return redirect('gatekeeper_dashboard')
        
        else:
            messages.error(request, 'Invalid Credentials')
            return redirect('gatekeeper_login')   
        
    return render(request,'gatekeeper/login.html')

def gatekeeper_dashboard(request):
    events = Event.objects.order_by('event_date').filter(is_published=True)

    context = {
        'events' : events
    }
    
    return render(request,'gatekeeper/dashboard.html',context)


def gatekeeper_logout(request):
    if request.method == 'POST':
        auth.logout(request)
        messages.success(request, 'You are now logged out')
        return redirect('index')
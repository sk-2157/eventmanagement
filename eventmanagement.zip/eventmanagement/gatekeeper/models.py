from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Gatekeeper(models.Model):
    gatekeeper = models.OneToOneField(User, on_delete=models.CASCADE)
    is_gatekeeper = models.BooleanField(default=True)

    

    def __str__(self):
        return self.gatekeeper.username